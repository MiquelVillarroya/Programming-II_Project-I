#ifndef PRIORITY_QUEUE_H
#define PRIORITY_QUEUE_H

#include <cassert>

template<class T>
class PriorityQueue
{
public:

	PriorityQueue() :
		_front(nullptr),
		_numElems(0)
	{ }

	~PriorityQueue()
	{
		clear();
	}

	unsigned int size() const
	{
		return _numElems;
	}

	bool empty() const
	{
		return _numElems == 0;
	}

	T &front()
	{
		assert(_numElems > 0 && "Cannot obtain the front of an empty queue");
		return _front->value;
	}

	const T &front() const
	{
		assert(_numElems > 0 && "Cannot obtain the front of an empty queue");
		return _front->value;
	}

	void enqueue(const T &value, int priority)
	{
		Node *n = new Node;
		n->priority = priority;
		n->value = value;
		n->next = nullptr;

		if (empty())
		{
			_front = n;
		}
		else
		{
			Node *itPrev = nullptr;
			Node *itCurr = _front;

			while (itCurr != nullptr)
			{
				if (priority >= itCurr->priority)
				{
					if (itPrev == nullptr) {
						_front = n;
					}
					else {
						itPrev->next = n;
					}
					n->next = itCurr;
					break;
				}

				itPrev = itCurr;
				itCurr = itCurr->next;
			}

			if (itCurr == nullptr)
			{
				itPrev->next = n;
			}
		}
		_numElems++;
	}

	void dequeue()
	{
		assert(_numElems > 0 && "Cannot dequeue from an empty queue");

		Node *newFront = _front->next;
		delete _front;
		_front = newFront;
		_numElems--;
	}

	void clear()
	{
		while (!empty())
		{
			dequeue();
		}
	}

private:

	struct Node
	{
		T value;
		int priority;
		Node *next;
	};

	Node *_front;
	unsigned int _numElems;
};

#endif // PRIORITY_QUEUE_H
