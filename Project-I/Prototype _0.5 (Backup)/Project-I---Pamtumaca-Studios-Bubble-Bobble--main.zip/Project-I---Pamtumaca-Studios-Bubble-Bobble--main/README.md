# Project I   Pamtumaca Studios Bubble Bobble

Link to the Github repository: https://github.com/MiquelVillarroya/Project-I---Pamtumaca-Studios-Bubble-Bobble-

Video of the implemented features:

Miquel's Github account:

Noa's Github account:


Our Project is a tribute of the arcade game Bubble Bobble, released in 1986 by TAITO. Bubble Bobble is a platform game in where the two main characters, Bub and Bob, have to surpass all the levels killing the enemies with their bubbles in order to rescue their girlfriends. 

CONTOLS: 
Move right             -   Right arrow
Move left              -   Left arrow
Jump                   -   Up arrow
Release Bubble         -   Space
Return to the menu     -   Esc
God Mode               -   F3
Force level transition -   N
Force Game Over stage  -   F

We are still developing the project but so far we have implemented this features:
- 


